package com.anaya.ai.control

import org.json.JSONArray
import org.json.JSONObject

/** Bridges Gemini function calls to the accessibility service. */
object PhoneController {

    private fun fn(name: String, desc: String, vararg params: Pair<String, String>): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (params.isNotEmpty()) {
            val props = JSONObject()
            params.forEach { (k, d) ->
                props.put(k, JSONObject().put("type", "STRING").put("description", d))
            }
            o.put(
                "parameters", JSONObject()
                    .put("type", "OBJECT")
                    .put("properties", props)
                    .put("required", JSONArray(params.map { it.first }))
            )
        }
        return o
    }

    fun declarations(): JSONArray = JSONArray()
        .put(fn("open_app", "Open an installed app by its name, e.g. WhatsApp, YouTube, Settings, Camera.",
            "app_name" to "Name of the app as shown on the phone"))
        .put(fn("go_home", "Go to the phone home screen."))
        .put(fn("go_back", "Press the Back button."))
        .put(fn("open_recents", "Open the recent apps screen."))
        .put(fn("open_notifications", "Pull down the notification shade."))
        .put(fn("tap_text", "Tap a button or item on the current screen by its visible text or label.",
            "text" to "Visible text or content description of the item to tap"))
        .put(fn("type_text", "Type text into the currently focused input field.",
            "text" to "Text to type"))
        .put(fn("scroll", "Scroll the current screen.",
            "direction" to "'down' (forward) or 'up' (backward)"))
        .put(fn("read_screen", "Read the visible text on the current screen so you can describe it or decide what to tap."))

    fun execute(name: String, args: JSONObject): String {
        val svc = AnayaAccessibilityService.instance
            ?: return "Accessibility service is OFF. Ask the user to enable ANAYA Ai in the Permissions menu."
        return try {
            when (name) {
                "open_app" -> svc.openApp(args.optString("app_name"))
                "go_home" -> svc.goHome()
                "go_back" -> svc.goBack()
                "open_recents" -> svc.openRecents()
                "open_notifications" -> svc.openNotifications()
                "tap_text" -> svc.clickText(args.optString("text"))
                "type_text" -> svc.typeText(args.optString("text"))
                "scroll" -> svc.scroll(args.optString("direction", "down"))
                "read_screen" -> svc.readScreen()
                else -> "Unknown action: $name"
            }
        } catch (e: Exception) {
            "Action failed: ${e.message}"
        }
    }
}

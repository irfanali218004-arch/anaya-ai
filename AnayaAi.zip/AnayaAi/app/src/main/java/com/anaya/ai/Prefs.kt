package com.anaya.ai

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

/** Saved settings (API key, model, voice, selected theme). Stored in the app's private storage. */
object Prefs {
    const val DEFAULT_MODEL = "gemini-3.8-live"
    const val DEFAULT_VOICE = "Aoede" // female Gemini voice

    private fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("anaya_prefs", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("api_key", "") ?: ""
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("api_key", v.trim()).apply()

    fun model(c: Context): String = sp(c).getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
    fun setModel(c: Context, v: String) =
        sp(c).edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply()

    fun voice(c: Context): String = sp(c).getString("voice", DEFAULT_VOICE) ?: DEFAULT_VOICE
    fun setVoice(c: Context, v: String) =
        sp(c).edit().putString("voice", v.trim().ifEmpty { DEFAULT_VOICE }).apply()

    fun theme(c: Context): Int = sp(c).getInt("theme", 0).coerceIn(0, 2)
    fun setTheme(c: Context, v: Int) = sp(c).edit().putInt("theme", v).apply()
}

/** Live state shared between the voice service and the UI. */
object AnayaState {
    val running = MutableStateFlow(false)
    val status = MutableStateFlow("Ready")
    val lines = MutableStateFlow<List<Pair<String, String>>>(emptyList())

    fun clear() {
        lines.value = emptyList()
    }

    /** Transcription arrives in fragments, so same-role fragments are merged into one line. */
    fun append(role: String, text: String) {
        lines.update { cur ->
            val next = if (cur.isNotEmpty() && cur.last().first == role && role != "Action") {
                cur.dropLast(1) + (role to (cur.last().second + text))
            } else {
                cur + (role to text)
            }
            next.takeLast(40)
        }
    }
}

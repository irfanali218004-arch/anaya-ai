package com.anaya.ai.control

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Lets ANAYA control the phone: open apps, tap on-screen text, type, scroll,
 * press Back/Home/Recents, open notifications and read the screen.
 */
class AnayaAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AnayaAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    fun openApp(query: String): String {
        val q = norm(query)
        if (q.isEmpty()) return "No app name given"
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { Triple(it.activityInfo.packageName, it.loadLabel(pm).toString(), norm(it.loadLabel(pm).toString())) }
            .filter { it.third.isNotEmpty() }
        val match = apps.firstOrNull { it.third == q }
            ?: apps.firstOrNull { it.third.contains(q) }
            ?: apps.firstOrNull { q.contains(it.third) }
            ?: return "App not found: $query"
        val intent = pm.getLaunchIntentForPackage(match.first) ?: return "Cannot launch ${match.second}"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return "Opened ${match.second}"
    }

    fun goHome(): String = if (performGlobalAction(GLOBAL_ACTION_HOME)) "Went to home screen" else "Failed"
    fun goBack(): String = if (performGlobalAction(GLOBAL_ACTION_BACK)) "Pressed back" else "Failed"
    fun openRecents(): String = if (performGlobalAction(GLOBAL_ACTION_RECENTS)) "Opened recent apps" else "Failed"
    fun openNotifications(): String =
        if (performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)) "Opened notifications" else "Failed"

    fun clickText(text: String): String {
        val root = rootInActiveWindow ?: return "Screen not readable right now"
        val nodes = root.findAccessibilityNodeInfosByText(text)
        for (n in nodes) {
            var cur: AccessibilityNodeInfo? = n
            while (cur != null && !cur.isClickable) cur = cur.parent
            if (cur != null && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "Tapped \"$text\""
        }
        return "Could not find \"$text\" on screen"
    }

    fun typeText(text: String): String {
        val root = rootInActiveWindow ?: return "Screen not readable right now"
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root)
        ?: return "No text field found"
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return if (field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Typed text" else "Typing failed"
    }

    fun scroll(direction: String): String {
        val root = rootInActiveWindow ?: return "Screen not readable right now"
        val node = findScrollable(root) ?: return "Nothing scrollable on screen"
        val action = if (direction.equals("up", true) || direction.equals("backward", true))
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        return if (node.performAction(action)) "Scrolled $direction" else "Scroll failed"
    }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "Screen not readable right now"
        val sb = StringBuilder()
        collect(root, sb)
        return sb.toString().take(2000).ifBlank { "Screen has no readable text" }
    }

    private fun collect(n: AccessibilityNodeInfo?, sb: StringBuilder) {
        if (n == null || sb.length > 2000) return
        val t = n.text?.toString() ?: n.contentDescription?.toString()
        if (!t.isNullOrBlank()) sb.append(t).append(" | ")
        for (i in 0 until n.childCount) collect(n.getChild(i), sb)
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i))?.let { return it }
        return null
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) findScrollable(n.getChild(i))?.let { return it }
        return null
    }
}

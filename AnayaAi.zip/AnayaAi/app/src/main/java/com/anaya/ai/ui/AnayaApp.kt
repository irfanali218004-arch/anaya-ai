package com.anaya.ai.ui

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.anaya.ai.AnayaState
import com.anaya.ai.Prefs
import com.anaya.ai.R
import com.anaya.ai.control.AnayaAccessibilityService
import com.anaya.ai.voice.VoiceService

// ---------- The three UI designs (Layer 3) ----------

data class AnayaTheme(
    val name: String,
    val tagline: String,
    val image: Int,
    val primary: Color,
    val secondary: Color,
    val bg: Color,
    val surface: Color,
)

val AnayaThemes = listOf(
    AnayaTheme(
        "ANAYA Pro", "Business suit · Neon cyan & purple",
        R.drawable.anaya_theme_business,
        Color(0xFF4FC3F7), Color(0xFFB388FF), Color(0xFF0A0F2E), Color(0xFF141A45)
    ),
    AnayaTheme(
        "ANAYA Emerald", "Green & gold anarkali",
        R.drawable.anaya_theme_green,
        Color(0xFFE0B04F), Color(0xFF2EBD85), Color(0xFF06161F), Color(0xFF0E2A33)
    ),
    AnayaTheme(
        "ANAYA Royal", "Royal blue & gold saree",
        R.drawable.anaya_theme_saree,
        Color(0xFFD4AF37), Color(0xFF5C7CFF), Color(0xFF070B24), Color(0xFF111A4A)
    ),
)

// ---------- Root ----------

@Composable
fun AnayaApp() {
    val ctx = LocalContext.current
    var themeId by remember { mutableIntStateOf(Prefs.theme(ctx)) }
    val theme = AnayaThemes[themeId]

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = theme.primary,
            secondary = theme.secondary,
            background = theme.bg,
            surface = theme.surface,
            onPrimary = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White,
        )
    ) {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        val labels = listOf("🎙" to "Talk", "🛡" to "Permissions", "🎨" to "Themes", "🔑" to "API Key")

        Scaffold(
            containerColor = theme.bg,
            bottomBar = {
                NavigationBar(containerColor = theme.surface) {
                    labels.forEachIndexed { i, (icon, label) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(icon, fontSize = 20.sp) },
                            label = { Text(label, fontSize = 11.sp) },
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> TalkScreen(theme, goTo = { tab = it })
                    1 -> PermissionsScreen(theme)
                    2 -> ThemesScreen(themeId) { themeId = it; Prefs.setTheme(ctx, it) }
                    else -> ApiScreen(theme)
                }
            }
        }
    }
}

// ---------- Layer 1: Talk ----------

private fun startVoice(ctx: Context) {
    ContextCompat.startForegroundService(
        ctx, Intent(ctx, VoiceService::class.java).setAction(VoiceService.ACTION_START)
    )
}

@Composable
fun TalkScreen(theme: AnayaTheme, goTo: (Int) -> Unit) {
    val ctx = LocalContext.current
    val running by AnayaState.running.collectAsState()
    val status by AnayaState.status.collectAsState()
    val lines by AnayaState.lines.collectAsState()

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startVoice(ctx)
        else Toast.makeText(ctx, "Microphone permission chahiye", Toast.LENGTH_SHORT).show()
    }

    fun toggle() {
        if (running) {
            ctx.startService(Intent(ctx, VoiceService::class.java).setAction(VoiceService.ACTION_STOP))
            return
        }
        if (Prefs.apiKey(ctx).isBlank()) {
            Toast.makeText(ctx, "Pehle API Key tab mein Gemini key save karein", Toast.LENGTH_LONG).show()
            goTo(3)
            return
        }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVoice(ctx)
        } else {
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Box(Modifier.fillMaxSize()) {
        Image(
            painterResource(theme.image), null,
            Modifier.fillMaxSize(), contentScale = ContentScale.Crop
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    0.45f to Color.Transparent,
                    1f to theme.bg.copy(alpha = 0.96f)
                )
            )
        )
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            lines.takeLast(4).forEach { (role, text) ->
                Text(
                    "$role: $text",
                    color = when (role) {
                        "ANAYA" -> theme.primary
                        "Action" -> theme.secondary
                        else -> Color.White
                    },
                    fontSize = 14.sp, maxLines = 3, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(status, color = theme.primary, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { toggle() },
                shape = CircleShape,
                modifier = Modifier.size(84.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (running) Color(0xFFE53935) else theme.primary
                )
            ) { Text(if (running) "■" else "🎙", fontSize = 28.sp, color = Color.White) }
            Spacer(Modifier.height(6.dp))
            Text(
                if (running) "Tap to stop" else "Tap to talk with ANAYA",
                color = Color.White.copy(alpha = .8f), fontSize = 12.sp
            )
        }
    }
}

// ---------- Layer 2: Permissions ----------

private data class PermItem(val title: String, val desc: String, val granted: Boolean, val grant: (() -> Unit)?)

private fun isAccessibilityOn(ctx: Context): Boolean {
    if (AnayaAccessibilityService.instance != null) return true
    val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
    val cn = ComponentName(ctx, AnayaAccessibilityService::class.java)
    return enabled.contains(cn.flattenToString(), true) || enabled.contains(cn.flattenToShortString(), true)
}

@Composable
fun PermissionsScreen(theme: AnayaTheme) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs) }
    }

    val micL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val notifL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val btL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    fun open(i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    @Suppress("UNUSED_VARIABLE") val refresh = tick // re-evaluate when returning from Settings

    val pm = ctx.getSystemService(PowerManager::class.java)
    val items = listOf(
        PermItem(
            "Accessibility (Phone Control)",
            "Apps kholna, tap, scroll, type aur screen padhna. Settings > Accessibility > ANAYA Ai ko ON karein. " +
                    "Agar option grey ho (sideload APK), App info > ⋮ > \"Allow restricted settings\" karein.",
            isAccessibilityOn(ctx)
        ) { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
        PermItem(
            "Microphone",
            "Live voice baat-cheet ke liye zaroori.",
            has(Manifest.permission.RECORD_AUDIO)
        ) { micL.launch(Manifest.permission.RECORD_AUDIO) },
        PermItem(
            "Notifications",
            "Voice session chalte waqt \"ANAYA is listening\" notification (Stop button ke saath).",
            Build.VERSION.SDK_INT < 33 || has(Manifest.permission.POST_NOTIFICATIONS)
        ) { notifL.launch(Manifest.permission.POST_NOTIFICATIONS) },
        PermItem(
            "Display over other apps",
            "Doosre apps ke upar ANAYA dikhane ke liye.",
            Settings.canDrawOverlays(ctx)
        ) {
            open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
        },
        PermItem(
            "Battery: Unrestricted",
            "Background mein voice session band na ho.",
            pm.isIgnoringBatteryOptimizations(ctx.packageName)
        ) {
            open(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
        },
        PermItem(
            "Bluetooth (headset)",
            "Bluetooth headset/earbuds se baat karne ke liye.",
            Build.VERSION.SDK_INT < 31 || has(Manifest.permission.BLUETOOTH_CONNECT)
        ) { btL.launch(Manifest.permission.BLUETOOTH_CONNECT) },
        PermItem("Internet", "Gemini se connect hone ke liye (automatic, koi action nahi).", true, null),
    )

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Spacer(Modifier.height(12.dp))
            Text("Permissions", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = theme.primary)
            Text(
                "${items.count { it.granted }} / ${items.size} granted",
                color = Color.White.copy(alpha = .7f), fontSize = 13.sp
            )
        }
        items(items) { p ->
            Card(colors = CardDefaults.cardColors(containerColor = theme.surface), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(p.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(
                            if (p.granted) "✅ ON" else "⚠ OFF",
                            color = if (p.granted) Color(0xFF66BB6A) else Color(0xFFFFB74D),
                            fontSize = 12.sp
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(p.desc, fontSize = 12.sp, color = Color.White.copy(alpha = .7f))
                    if (!p.granted && p.grant != null) {
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { p.grant.invoke() }) { Text("Allow") }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

// ---------- Layer 3: Themes (the three UI designs) ----------

@Composable
fun ThemesScreen(selected: Int, onSelect: (Int) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(Modifier.height(12.dp))
            Text("UI Themes", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text("Teen design mein se ek chunein", color = Color.White.copy(alpha = .7f), fontSize = 13.sp)
        }
        items(AnayaThemes.size) { i ->
            val t = AnayaThemes[i]
            val isSel = i == selected
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onSelect(i) },
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = t.surface),
                border = BorderStroke(if (isSel) 3.dp else 1.dp, if (isSel) t.primary else Color.White.copy(alpha = .15f))
            ) {
                Image(
                    painterResource(t.image), null,
                    Modifier.fillMaxWidth().height(220.dp),
                    contentScale = ContentScale.Crop, alignment = Alignment.TopCenter
                )
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(t.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = t.primary)
                        Text(t.tagline, fontSize = 12.sp, color = Color.White.copy(alpha = .75f))
                    }
                    Text(if (isSel) "✅ Selected" else "Select", color = t.primary, fontSize = 13.sp)
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

// ---------- API Key ----------

@Composable
fun ApiScreen(theme: AnayaTheme) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(Prefs.apiKey(ctx)) }
    var model by remember { mutableStateOf(Prefs.model(ctx)) }
    var voice by remember { mutableStateOf(Prefs.voice(ctx)) }
    var show by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(Prefs.apiKey(ctx).isNotBlank()) }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Image(
            painterResource(R.drawable.anaya_logo), null,
            Modifier.size(120.dp).clip(CircleShape), contentScale = ContentScale.Crop
        )
        Text("Gemini API", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = theme.primary)
        Text(
            if (saved) "✅ Key saved" else "Key abhi save nahi hai",
            color = if (saved) Color(0xFF66BB6A) else Color(0xFFFFB74D), fontSize = 13.sp
        )

        OutlinedTextField(
            value = key, onValueChange = { key = it; saved = false },
            label = { Text("Gemini API Key") }, singleLine = true,
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            if (show) "🙈 Hide key" else "👁 Show key", color = theme.secondary, fontSize = 12.sp,
            modifier = Modifier.clickable { show = !show }
        )
        OutlinedTextField(
            value = model, onValueChange = { model = it }, label = { Text("Live voice model") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = voice, onValueChange = { voice = it }, label = { Text("Voice (female: Aoede)") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                Prefs.setApiKey(ctx, key)
                Prefs.setModel(ctx, model)
                Prefs.setVoice(ctx, voice)
                saved = key.isNotBlank()
                Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save") }

        OutlinedButton(
            onClick = {
                Prefs.setApiKey(ctx, "")
                key = ""; saved = false
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Remove saved key") }

        Text(
            "Key sirf is phone ke private storage mein rehti hai. Free key: aistudio.google.com/apikey",
            fontSize = 11.sp, color = Color.White.copy(alpha = .6f), textAlign = TextAlign.Center
        )
    }
}

package com.anaya.ai.voice

import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Minimal Gemini Live API client over a raw WebSocket (audio in 16 kHz PCM, audio out 24 kHz PCM). */
class GeminiLiveClient(
    private val apiKey: String,
    private val model: String,
    private val voice: String,
    private val systemPrompt: String,
    private val tools: JSONArray,
    private val cb: Callback,
) {
    interface Callback {
        fun onReady()
        fun onAudio(pcm: ByteArray)
        fun onTranscript(role: String, text: String)
        fun onInterrupted()
        fun onToolCall(id: String, name: String, args: JSONObject)
        fun onClosed(reason: String)
    }

    private val http = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var ws: WebSocket? = null

    @Volatile
    var ready = false
        private set

    fun connect() {
        val url = "wss://generativelanguage.googleapis.com/ws/" +
                "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"
        ws = http.newWebSocket(Request.Builder().url(url).build(), listener)
    }

    private fun setupMessage(): String {
        val setup = JSONObject()
            .put("model", if (model.startsWith("models/")) model else "models/$model")
            .put(
                "generationConfig", JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig", JSONObject().put(
                            "voiceConfig", JSONObject().put(
                                "prebuiltVoiceConfig", JSONObject().put("voiceName", voice)
                            )
                        )
                    )
            )
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", tools)))
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
        return JSONObject().put("setup", setup).toString()
    }

    fun sendAudio(pcm16k: ByteArray) {
        if (!ready) return
        val msg = JSONObject().put(
            "realtimeInput", JSONObject().put(
                "audio", JSONObject()
                    .put("data", Base64.encodeToString(pcm16k, Base64.NO_WRAP))
                    .put("mimeType", "audio/pcm;rate=16000")
            )
        )
        ws?.send(msg.toString())
    }

    fun sendToolResponse(id: String, name: String, result: String) {
        val msg = JSONObject().put(
            "toolResponse", JSONObject().put(
                "functionResponses", JSONArray().put(
                    JSONObject().put("id", id).put("name", name)
                        .put("response", JSONObject().put("result", result))
                )
            )
        )
        ws?.send(msg.toString())
    }

    fun close() {
        ready = false
        ws?.close(1000, "bye")
        ws = null
    }

    private val listener = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            webSocket.send(setupMessage())
        }

        override fun onMessage(webSocket: WebSocket, text: String) = handle(text)
        override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(bytes.utf8())

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            webSocket.close(1000, null)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            ready = false
            cb.onClosed(if (reason.isNotBlank()) reason else "Connection closed ($code)")
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            ready = false
            val code = response?.code?.let { " (HTTP $it)" } ?: ""
            cb.onClosed((t.message ?: "Connection failed") + code)
        }
    }

    private fun handle(raw: String) {
        val j = try { JSONObject(raw) } catch (e: Exception) { return }

        if (j.has("setupComplete")) {
            ready = true
            cb.onReady()
        }

        j.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted")) cb.onInterrupted()

            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    val data = parts.optJSONObject(i)?.optJSONObject("inlineData")?.optString("data")
                    if (!data.isNullOrEmpty()) cb.onAudio(Base64.decode(data, Base64.DEFAULT))
                }
            }
            sc.optJSONObject("inputTranscription")?.optString("text")
                ?.takeIf { it.isNotEmpty() }?.let { cb.onTranscript("You", it) }
            sc.optJSONObject("outputTranscription")?.optString("text")
                ?.takeIf { it.isNotEmpty() }?.let { cb.onTranscript("ANAYA", it) }
        }

        j.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
            for (i in 0 until calls.length()) {
                val c = calls.getJSONObject(i)
                cb.onToolCall(
                    c.optString("id"),
                    c.optString("name"),
                    c.optJSONObject("args") ?: JSONObject()
                )
            }
        }
    }
}

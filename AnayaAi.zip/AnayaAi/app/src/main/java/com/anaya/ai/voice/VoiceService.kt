package com.anaya.ai.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.anaya.ai.AnayaState
import com.anaya.ai.Prefs
import com.anaya.ai.control.PhoneController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Foreground service so the voice session (and microphone) keeps working
 * even after ANAYA opens another app.
 */
class VoiceService : Service() {

    companion object {
        const val ACTION_START = "com.anaya.ai.START"
        const val ACTION_STOP = "com.anaya.ai.STOP"
        private const val CHANNEL_ID = "anaya_voice"

        private const val SYSTEM_PROMPT =
            "You are ANAYA, a warm, smart, friendly female AI assistant living on the user's Android phone. " +
                    "Always speak as a woman. Reply in the same language the user speaks (Hindi, Urdu, English or Hinglish). " +
                    "Keep replies short and natural because this is a live voice conversation. " +
                    "You can control the phone with tools: open apps, go home/back, open recents or notifications, " +
                    "tap on-screen text, type text, scroll and read the screen. " +
                    "Use a tool whenever the user asks for a phone action, then tell them briefly what you did. " +
                    "Before anything sensitive or irreversible (sending messages, payments, deleting data, " +
                    "changing important settings) ask the user for a spoken confirmation first. " +
                    "If a tool says accessibility is off, tell the user to enable it from the Permissions menu."
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var client: GeminiLiveClient? = null
    private var audio: AudioIO? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSession()
            stopSelf()
            return START_NOT_STICKY
        }
        startSession()
        return START_NOT_STICKY
    }

    private fun startSession() {
        if (AnayaState.running.value) return

        ServiceCompat.startForeground(
            this, 1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )

        val key = Prefs.apiKey(this)
        if (key.isBlank()) {
            AnayaState.status.value = "API key missing"
            stopSelf()
            return
        }

        AnayaState.clear()
        AnayaState.running.value = true
        AnayaState.status.value = "Connecting…"

        val io = AudioIO { chunk -> client?.sendAudio(chunk) }
        audio = io

        client = GeminiLiveClient(
            apiKey = key,
            model = Prefs.model(this),
            voice = Prefs.voice(this),
            systemPrompt = SYSTEM_PROMPT,
            tools = PhoneController.declarations(),
            cb = object : GeminiLiveClient.Callback {
                override fun onReady() {
                    AnayaState.status.value = "Listening…"
                    try {
                        io.start()
                    } catch (e: Exception) {
                        fail("Microphone error: ${e.message}")
                    }
                }

                override fun onAudio(pcm: ByteArray) {
                    AnayaState.status.value = "ANAYA is speaking…"
                    io.play(pcm)
                }

                override fun onTranscript(role: String, text: String) {
                    AnayaState.append(role, text)
                }

                override fun onInterrupted() {
                    io.flush()
                    AnayaState.status.value = "Listening…"
                }

                override fun onToolCall(id: String, name: String, args: JSONObject) {
                    scope.launch(Dispatchers.Main) {
                        val result = PhoneController.execute(name, args)
                        AnayaState.append("Action", "$name → $result")
                        client?.sendToolResponse(id, name, result)
                    }
                }

                override fun onClosed(reason: String) {
                    fail(reason)
                }
            }
        ).also { it.connect() }
    }

    private fun fail(reason: String) {
        AnayaState.status.value = "Stopped: $reason"
        stopSession(keepStatus = true)
        stopSelf()
    }

    private fun stopSession(keepStatus: Boolean = false) {
        client?.close()
        client = null
        audio?.stop()
        audio = null
        AnayaState.running.value = false
        if (!keepStatus) AnayaState.status.value = "Ready"
    }

    override fun onDestroy() {
        stopSession(keepStatus = AnayaState.status.value.startsWith("Stopped"))
        scope.cancel()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "ANAYA voice", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, VoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("ANAYA Ai is listening")
            .setContentText("Tap Stop to end the voice session")
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
    }
}

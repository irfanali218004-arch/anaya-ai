package com.anaya.ai.voice

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import java.util.concurrent.LinkedBlockingQueue

/** Mic capture (16 kHz mono PCM16) and speaker playback (24 kHz mono PCM16). */
class AudioIO(private val onMicChunk: (ByteArray) -> Unit) {

    private var recorder: AudioRecord? = null
    private var track: AudioTrack? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null

    private val playQueue = LinkedBlockingQueue<ByteArray>()

    @Volatile
    private var running = false
    private var micThread: Thread? = null
    private var playThread: Thread? = null

    @SuppressLint("MissingPermission") // RECORD_AUDIO is checked before the service starts
    fun start() {
        running = true

        val minRec = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minRec, 6400)
        )
        if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(rec.audioSessionId)?.also { it.enabled = true }
        if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(rec.audioSessionId)?.also { it.enabled = true }
        recorder = rec

        val minPlay = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val trk = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(24000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minPlay, 24000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        trk.play()
        track = trk

        rec.startRecording()

        micThread = Thread {
            val buf = ByteArray(1280) // 40 ms
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) onMicChunk(buf.copyOf(n))
            }
        }.also { it.start() }

        playThread = Thread {
            while (running) {
                val chunk = playQueue.poll(100, java.util.concurrent.TimeUnit.MILLISECONDS) ?: continue
                track?.write(chunk, 0, chunk.size)
            }
        }.also { it.start() }
    }

    fun play(pcm24k: ByteArray) {
        playQueue.offer(pcm24k)
    }

    /** Called when the user interrupts ANAYA: drop queued speech immediately. */
    fun flush() {
        playQueue.clear()
        track?.let {
            it.pause()
            it.flush()
            it.play()
        }
    }

    fun stop() {
        running = false
        micThread?.join(300)
        playThread?.join(300)
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.release()
        try { track?.stop() } catch (_: Exception) {}
        track?.release()
        aec?.release()
        ns?.release()
        recorder = null
        track = null
        playQueue.clear()
    }
}

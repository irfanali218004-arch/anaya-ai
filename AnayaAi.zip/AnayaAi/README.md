# ANAYA Ai (Android)

Voice assistant app: female live voice (Gemini Live API, default model `gemini-3.8-live`),
phone control via Accessibility Service, 3 UI themes, Gemini API key screen.

## Build
1. Android Studio (Ladybug or newer) > Open > this folder (`AnayaAi`).
2. Let Gradle sync (it creates the Gradle wrapper), then Run on a phone (Android 8.0+).
3. Build > Build APK(s) for a shareable APK.

## First run
1. **API Key** tab: paste your Gemini key (https://aistudio.google.com/apikey) > Save.
2. **Permissions** tab: allow everything, especially Accessibility (Settings > Accessibility > ANAYA Ai).
   If the switch is greyed out on a sideloaded APK: App info > ⋮ > Allow restricted settings.
3. **Talk** tab: tap the mic and speak, e.g. "ANAYA, YouTube kholo".

## Menu (bottom bar)
- Talk: live voice
- Permissions: all permissions with ON/OFF status and Allow buttons
- Themes: the 3 designs (ANAYA Pro, ANAYA Emerald, ANAYA Royal)
- API Key: Gemini key, model id, voice name

## Phone actions ANAYA can do
open_app, go_home, go_back, open_recents, open_notifications, tap_text, type_text, scroll, read_screen.

## Files
- `voice/GeminiLiveClient.kt`: Live API WebSocket (setup, audio in/out, tool calls)
- `voice/VoiceService.kt`, `voice/AudioIO.kt`: foreground mic session, playback
- `control/AnayaAccessibilityService.kt`, `control/PhoneController.kt`: phone control
- `ui/AnayaApp.kt`: all screens and the 3 themes
- Images: `res/drawable-nodpi/`
